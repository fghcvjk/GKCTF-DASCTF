<?php
/* For admin users. */
$config->rights->admin['admin']['index']      = 'index';
$config->rights->admin['admin']['switchlang'] = 'switchlang';

$config->rights->admin['misc']['ping']   = 'ping';
$config->rights->admin['misc']['about']  = 'about';
$config->rights->admin['misc']['thanks'] = 'thanks';

$config->rights->admin['user']['setpassword'] = 'setpassword';
$config->rights->admin['user']['setemail']    = 'setemail';
$config->rights->admin['user']['setsecurity'] = 'setsecurity';

$config->rights->admin['visual']['editpowerby'] = 'editpowerby';

$config->rights->admin['guarder']['getemailcode'] = 'getemailcode';
