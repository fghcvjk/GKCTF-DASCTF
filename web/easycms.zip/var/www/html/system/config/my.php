<?php
$config->installed    = true;	
$config->debug        = false;	
$config->requestType  = 'PATH_INFO2';	
$config->db->host     = '127.0.0.1';	
$config->db->port     = '3306';	
$config->db->name     = 'itislasttime';	
$config->db->user     = 'root';	
$config->db->password = 'root';		
$config->db->prefix   = 'eps_';	