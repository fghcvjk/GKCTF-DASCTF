ALTER table `eps_article`  CHANGE `contribution` `submission` enum('0', '1', '2', '3') NOT NULL DEFAULT '0';
